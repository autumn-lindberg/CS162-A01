#ifndef MAIN_H
#define MAIN_H
const int MAX_STUDENTS = 30;

void welcome();
char menu();
int main();
#endif
